package com.example.demo.model;
import java.lang.reflect.Constructor;
import java.time.*;
import java.util.*;


public class ticket {
    
    private String projectName; //pair the ticket to the project
    private String issueTitle; //title the ticket
    private String[] status = {"To Do", "In Progress", "Done"}; //{To do, In Progress, Done}
    private String[] issueType = {"Functional Bug", "Visual Bug", "Usability Bug", "Performance Bug"}; //{Functional Bug, Visual Bug, Usability Bug, Perfomrance Bug}
    private LocalDate dateCreated; //will keep track of the date created
    private LocalDate dateCompleted; //this will keep track of the date the bug was addressed.    



    public ticket(String projectName, String issueTitle,  String[] status, String[] issueType, LocalDate dateCreated)
    {
        this.projectName = projectName;
        this.issueTitle = issueTitle;
        this.status = status;
        this.issueType = issueType;
        this.dateCreated = dateCreated;
    }



    //getters and setters
    public String getProjectName() {
        return this.projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getIssueTitle() {
        return this.issueTitle;
    }

    public void setIssueTitle(String issueTitle) {
        this.issueTitle = issueTitle;
    }

    public String[] getStatus() {
        return this.status;
    }

    public void setStatus(String[] status) {
        this.status = status;
    }

    public String[] getIssueType() {
        return this.issueType;
    }

    public void setIssueType(String[] issueType) {
        this.issueType = issueType;
    }

    public LocalDate getDateCreated() {
        return this.dateCreated;
    }

    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public LocalDate getDateCompleted() {
        return this.dateCompleted;
    }

    public void setDateCompleted(LocalDate dateCompleted) {
        this.dateCompleted = dateCompleted;
    }

    

    //toString
    @Override
    public String toString() {
        return "{" +
            " projectName='" + getProjectName() + "'" +
            ", issueTitle='" + getIssueTitle() + "'" +
//            ", status='" + getStatus() + "'" +
//            ", issueType='" + getIssueType() + "'" +
            ", dateCreated='" + getDateCreated() + "'" +
            ", dateCompleted='" + getDateCompleted() + "'" +
            "}";
    }

     
}
