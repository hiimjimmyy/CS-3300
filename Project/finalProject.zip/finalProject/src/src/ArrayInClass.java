import java.util.*;

public class ArrayInClass {

        public static void main(String[] Args)
        {
            //objects of classes
            FunctionLibrary functionLib = new FunctionLibrary();
            data newDataValue = new data();

            //scanner for user input
            Scanner scanner = new Scanner(System.in);


            //program start
            do
            {
                functionLib.lineBreaker();

                //display menu
                newDataValue.Display_Menu(0);

                System.out.print("Input a valid option from 0 to ");
                newDataValue.Display_Menu(1);
                System.out.println("");
                int userInput = scanner.nextInt();
                userInput = functionLib.validInputBetweenRange(userInput, 0, 4); //this is so trash please fix this when you can

                if(userInput == 0)
                {
                    break;
                }

                //executes command based on obtianed user input
                newDataValue.executeCommandFromDisplayMenu(userInput);
            }
            while(true);

            System.out.println("This exercise taught us the basics of using a classes and objects.  It taught us how and when to use private variables and public mutator methods. This exercise also taught us the basics of ArrayLists. We learned how to create, input a number to, display, search, and clear an ArrayList. We also used a main method to create an object from A class we created.");

        }
    }
