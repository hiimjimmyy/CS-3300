import java.io.*;
import java.util.*;


public class FunctionLibrary {
    public void lineBreaker()
    {
        System.out.println("*************************");
    }

    public int validInputBetweenRange(int inputValue, int minRange, int maxRange)
    {
        Scanner scanner = new Scanner(System.in);
        do
        {
            if(inputValue > maxRange || inputValue < minRange)
            {
                System.out.println("Please enter a valid integer from "+ minRange+ " to "+ maxRange);
                int userInput = scanner.nextInt();
                inputValue = userInput;
            }
            else
            {
                return inputValue;
            }
        }
        while(true);
    }

    public static String readTheContentOfJavaFileIntoAString(String input_plaintext_filename)
    {
        File file = new File(input_plaintext_filename);

        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String st;
            while ((st = br.readLine()) != null)
            {
                return st;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        return null;
    }
}
