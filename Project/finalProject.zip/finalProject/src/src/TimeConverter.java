import javax.swing.JOptionPane;
import javax.swing.JFrame;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TimeConverter
{
    //global variables for conversion
    public static final int MinutesInAnHour = 60;

    public static void main(String [] args)
    {
        ExecutorService ex = Executors.newCachedThreadPool();
        // System.out.println("Hello World!");
        final int MinimumMinuteValue = 60;

        int ReturnValueFromPrompt = PromtPaneMessage(MinimumMinuteValue);
        ConvertInputIntToHours(ReturnValueFromPrompt);

        System.out.println("This exercise taught us the basics of how to use JOptionPane to receive user input from the keyboard, as well as how to display output via GUI. We also learned how to use the % or modulus operator to calculate the remainder of minutes, and how to convert a string to an integer to perform mathematical operations on the string value.");

        ex.shutdown();
    }

    public static int PromtPaneMessage(int MinimumMinuteValue)
    {
        String message;
        message = JOptionPane.showInputDialog("Input a number of minutes greater than 60:");

        int OutputValue = Integer.parseInt(message);

        while(OutputValue <= MinimumMinuteValue)
        {
            System.out.println("Value is not greater than 60, please try again");
            //there's a bug here; after the inital rejection, it will keep prompting the dialog box
            message = JOptionPane.showInputDialog("Input a number of minutes greater than 60:");
        }
        return OutputValue;
    }

    public static void ConvertInputIntToHours(int inputValueFromPrompt)
    {
        int hours;
        int minutes;

        minutes = inputValueFromPrompt%TimeConverter.MinutesInAnHour;
        hours = (inputValueFromPrompt - minutes)/TimeConverter.MinutesInAnHour;


        // System.out.println("this is the amount of hours: " + hours);
        // System.out.println("this is the amount of minutes: " + minutes);

        //create return dialog box
        System.out.println("This is equivalent to " + hours + " hours and " + minutes + " minutes");
    }

}
