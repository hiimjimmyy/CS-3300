import java.lang.reflect.Array;
import java.util.*;
import java.io.*;
import java.util.function.Function;


public class Main {

    public static void invokeCommand(Integer command)
    {
        Map<Integer, Runnable> listOfCommands = new HashMap<>();
        listOfCommands.put(0, () -> System.out.println("Ending Program"));
        listOfCommands.put(1, () -> TimeConverter.main(new String[0]));
        listOfCommands.put(2, () -> LottoSimulator.main(new String[0]));
        listOfCommands.put(3, () -> PrimeNumbers.main(new String[0]));
        listOfCommands.put(4, () -> ArrayInClass.main(new String[0]));
        listOfCommands.put(5, () -> FileIO.main(new String[0]));

        listOfCommands.get(command).run();
    }

    public static int displayMenu(Map<Integer, String> listOfOptions)
    {
        Scanner scanner = new Scanner(System.in);

        //display list
        int counter = 0;
        for(String value : listOfOptions.values())
        {

            System.out.println(value+ " : " + counter);
            counter += 1;
        }

        System.out.println("\nSelect An Exercise: ");
        String userInput = scanner.nextLine();
        int userInputChoice;

        do
        {
            try
            {
                userInputChoice = Integer.parseInt(userInput);

                System.out.println("You selected: "+ listOfOptions.get(userInputChoice) + "\n");

                break;
            }
            catch(Exception e)
            {
                System.out.println("Please enter a valid integer value\n");
                userInput = scanner.nextLine();
                System.out.println(e);
            }

        }
        while(true);

        return userInputChoice;
    }

    public static void main(String[] args) {

        //initalizes list of exercies
        Map<Integer, String> listOfOptions = new HashMap<>();
        listOfOptions.put(0, "\nQuit Program");
        listOfOptions.put(1, "Time Converter");
        listOfOptions.put(2, "Lotto Simulator");
        listOfOptions.put(3, "Prime Numbers");
        listOfOptions.put(4, "ArrayList in Class");
        listOfOptions.put(5, "File Input and Output");

        //function library
        FunctionLibrary functionLib = new FunctionLibrary();

        System.out.println("The title of the project is: Our favorite exercises from object oriented programming!");
        System.out.println("By Jimmy and Michael\n");
        functionLib.lineBreaker();

        do
        {
            int userSelectedChoice = displayMenu(listOfOptions);

            if(userSelectedChoice == 0)
                break;

            invokeCommand(userSelectedChoice);
        }
        while(true);


        //recursion
        String professor = "Cyril Harris";
        int lengthOfProfessorsName = professor.length();
        int counter = 0;
        System.out.print("Thank you for an awesome semester Professor ");
        RecursivlyPrintingStirng(professor, lengthOfProfessorsName, counter);
        System.out.print("!\nThis thank you message was brought to you by.. recursion");
    }

    public static void RecursivlyPrintingStirng(String inputString, int lengthOfProfessorsName, int counter)
    {
        if(counter < lengthOfProfessorsName)
        {
            System.out.print(inputString.charAt(counter));
            RecursivlyPrintingStirng(inputString, lengthOfProfessorsName, counter+1);
        }
    }
}