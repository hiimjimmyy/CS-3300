import java.util.ArrayList;
import java.util.Scanner;

public class PrimeNumbers {
    public static void main(String[] args)
    {
        Integer outputFromFunctionThatObtainsInput = null;
        Boolean quitProgram = false;
        Scanner usersChoice = new Scanner(System.in);
        char usersChoiceInput;

        //repeat program until the user opts to quit
        do
        {
            //obtain user input
            outputFromFunctionThatObtainsInput = askUserToInputANumberAndReturnThatValue();
            // System.out.println(outputFromFunctionThatObtainsInput);

            //finds all the prime numbers from 0 to the input value
            ArrayList<Integer> listOfAllPrimeNumbers = findPrimeNumbersWithinRangeOfZeroToInputValueAndReturnInArrayList(outputFromFunctionThatObtainsInput);

            //we will pass this integer list to a functon that will process display in the requested format
            processDisplayAndFormat(outputFromFunctionThatObtainsInput, listOfAllPrimeNumbers);

            //ask if user wants to repeat the program
            System.out.print("Do you want to quit? If you do, input 'y' ");
            usersChoiceInput = usersChoice.next().charAt(0);

            //if user wants to quit, set boolean to true to break out of loop
            if(usersChoiceInput == 'y')
            {
                quitProgram = true;
            }

        }
        while(!quitProgram);

        System.out.println("This program taught us how use different types of loops, specifically the for loop to iterate through the list of numbers greater than 2 up to the inputted value.  We also used either a while or a do while loop to allow the user to use the program over and over again until they indicate that they want to quit.");

    }

    public static void processDisplayAndFormat(Integer inputValue, ArrayList<Integer> listOfPrimeValuesFromZeroToInputValue)
    {
        System.out.print("The following are all the prime numbers from 1 up to "+ inputValue+ ": ");
        for(int i: listOfPrimeValuesFromZeroToInputValue)
        {
            System.out.print(i+ " ");
        }
        System.out.println("\n");
    }

    public static int askUserToInputANumberAndReturnThatValue()
    {
        //creating an object of scanner to obtain input from user
        Scanner scan = new Scanner(System.in);

        //obtain input from user in console
        System.out.print("Enter a positive integer ");
        int input = scan.nextInt();

        //return user input value
        return input;
    }

    public static ArrayList<Integer> findPrimeNumbersWithinRangeOfZeroToInputValueAndReturnInArrayList(Integer input) {
        ArrayList<Integer> returnArrayOfAllPrimeValuesWithinInput = new ArrayList<Integer>();
        //[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
        //a prime number is a number thats only divisible by 1 or itself
        int firstPrimeNumber = 2;

        for (int i = 0; i < input; i++) {
            if (i > 1) {
                found:
                {
                    for (int j = firstPrimeNumber; j < i; j++) {
                        if (i % j == 0) {
                            break found;
                        }
                    }
                    returnArrayOfAllPrimeValuesWithinInput.add(i);
                }
            }
        }

        return returnArrayOfAllPrimeValuesWithinInput;
    }
}
